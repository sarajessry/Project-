document.getElementById("tshirtForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const color = document.getElementById("color").value;
  const text = document.getElementById("text").value;
  const image = document.getElementById("imageUpload").files[0];
  const font = document.getElementById("fontSelect").value;

  const tshirt = document.getElementById("tshirt");
  tshirt.style.backgroundColor = color;

  // تحديث النص
  const tshirtText = document.getElementById("tshirtText");
  tshirtText.textContent = text;
  tshirtText.style.fontFamily = font;

  // عرض الصورة
  const tshirtImage = document.getElementById("tshirtImage");
  if (image) {
    const reader = new FileReader();
    reader.onload = function (e) {
      tshirtImage.src = e.target.result;
      tshirtImage.style.display = "block";
    };
    reader.readAsDataURL(image);
  } else {
    tshirtImage.src = "";
    tshirtImage.style.display = "none";
  }
});
